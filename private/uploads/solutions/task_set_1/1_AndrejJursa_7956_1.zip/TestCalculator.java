import static org.junit.Assert.*;

import org.junit.Test;

public class TestCalculator {

	@Test
	public void testAdd() {
		Calculator c = new Calculator();
		assertEquals("Sucet 1 + 1 = 2", 2, c.add(1,1));
		assertEquals("Sucet 1 + (-1) = 0", 0, c.add(1, -1));
		LISTTests.addTaskEvaluation(25);
	}		

	@Test
	public void testSub() {
		Calculator c = new Calculator();
		assertEquals("Odcitanie 1 - 1 = 0", 0, c.sub(1,1));
		assertEquals("Odcitanie 1 - (-1)", 2, c.sub(1,-1));
		LISTTests.addTaskEvaluation(25);
	}

	@Test
	public void testMult() {
		Calculator c = new Calculator();
		assertEquals("Sucin 2 * 2 = 4", 4, c.mult(2,2));
		assertEquals("Sucin 10 * 0 = 0", 0, c.mult(10, 0));
		assertEquals("Sucin -1 * -1 = 1", 1, c.mult(-1, -1));
		LISTTests.addTaskEvaluation(25);
	}

	@Test
	public void testFact() {
		Calculator c = new Calculator();
		assertEquals("Faktorial 0 = 1", 1, c.fact(0));
		assertEquals("Faktorial 1 = 1", 1, c.fact(1));
		assertEquals("Faktorial -1 = 0", 0, c.fact(-1));
		assertEquals("Faktorial 3 = 6", 6, c.fact(3));
		LISTTests.addTaskEvaluation(25);
	}

}
