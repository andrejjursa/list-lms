import os, os.path, sys, hashlib, base64

class LISTTestScoring:
	__scoreTable = {}

	def __init__(self):
		pass

	def updateScore(self, scoreName, scoreToAdd, scoreMaximum = None):
		if scoreMaximum is not None:
			if scoreName in self.__scoreTable:
				self.__scoreTable[scoreName].setMaximum(scoreMaximum)
				self.__scoreTable[scoreName].addCurrent(scoreToAdd)
			else:
				score = ScoreItem(scoreToAdd, scoreMaximum)
				self.__scoreTable[scoreName] = score
		else:
			if scoreName in self.__scoreTable:
				self.__scoreTable[scoreName].addCurrent(scoreToAdd)
			else:
				print('Scoring error, you are trying to modify non-existing score name: ' + scoreName)		

	def setScore(self, scoreName, scoreToSet, scoreMaximum = None):
		if scoreMaximum is not None:
			if scoreName in self.__scoreTable:
				del self.__scoreTable[scoreName]
			score = ScoreItem(scoreToSet, scoreMaximum)
			self.__scoreTable[scoreName] = score
		else:
			if scoreName in self.__scoreTable:
				self.__scoreTable[scoreName].setCurrent(scoreToSet)
			else:
				print('Scoring error, you are trying to modify non-existing score name: ' + scoreName)

class ScoreItem:
	__current = 0.0
	__maximum = 0.0
	
	def __init__(self, current, maximum):
		self.__current = current
		self.__maximum = maximum
		if self.__maximum < 0.0:
			self.__maximum = 0.0
		if self.__current < 0.0:
			self.__current = 0.0
		elif self.__current > self.__maximum:
			self.__current = self.__maximum

	def getCurrent(self):
		return self.__current

	def getMaximum(self):
		return self.__maximum

	def setCurrent(self, current):
		self.__current = current
		if self.__current < 0.0:
			self.__current = 0.0
		elif self.__current > self.__maximum:
			self.__current = self.__maximum

	def setMaximum(self, maximum):
		self.__maximum = maximum
		if self.__maximum < 0.0:
			self.__maximum = 0.0
		if self.__current > self.__maximum:
			self.__current = self.__maximum

	def addCurrent(self, add):
		self.setCurrent(self.getCurrent() + add)

	def __str__(self):
		return '{0} / {1}'.format(self.__current, self.__maximum)

