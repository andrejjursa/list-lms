********************************************************************************
PROJEKT: Scrabble
MENO: Andrej Jursa
********************************************************************************
Spustenie:
V eclipse skompilovat a spustit bud subor Scrabble.java alebo subor
ScrabbleApplet.java.
Bohuzial, neslo vytvorit funkcny jar subor, ani vygenerovat podpisovy kluc,
cize jedina moznost spustenia je z eclipse.
Kvoli obmedzeniu kompilatora sa ani nedalo vytvorit cely slovnik ako jeden
datovy objekt (slovnik ma viac ako 200000 slov).
********************************************************************************
Co projekt robi / herne pravidla:
Po spusteni aplikacie / appletu sa zobrazi prazdny hraci plan. Vedla hracieho
planu (napravo) sa nachadzaju dve tlacidla. Kliknite na tlacidlo Nova hra,
zadajte pocet hracov od 2 do 4, mena hracov a mozete hrat. Zacina vzdy prvy
hrac.
Pod hracim planom sa zobrazi zasobnik pismen hraca, ktory je na tahu. Mysou
oznacte pismeno, ktore chcete umistnit na hraci plan a nasledne kliknite na
hraci plan. Kliknite na oznacene pismeno v zasobniku a odznaci sa. Na hracom
plane sa daju pismena odoberat, ak su oramovane cervene.
Prve slovo musi byt umiestnene tak, aby prechadzalo strednym stvorcekom,
oznacenym oranzovym kruzkom.
Kazde slovo musi byt napojene na uz existujuce slovo, moze ho bud rozsirovat,
alebo vedla tohoto slova vytvorit ine slovo.
Slova sa citaju vzdy iba z lava do prava alebo z hora nadol.
Niektore stvorce upravuju hodnotu slov nasledovne:
  svetlomodry - 2x hodnota pismena,
  tmavomodry - 3x hodnota pismena,
  svetlocerveny - 2x hodnota celeho slova,
  tmavocerveny - 3x hodnota celeho slvoa.
Ked ste dokoncili tah, tj. umiestnili vsetky slova, stlacte tlacidlo Dalsi hrac.
Ak boli vsetky slova akceptovane, dostanete body a pokracuje dalsi hrac.
V pripade, ze nejake slovo nebolo spravne, body zan nedostanete a pismena sa 
vratia do vasho zasobnika.
Ak nezlozite ziadne slovo, hra sa vas opyta, ci chcete svoj tah zopakovat.
Ak v tahu neziskate body, a pustite k hre dalsieho hraca, bude vam zapisane
neuspesne kolo.
Ak vsetci hraci maju 2 a viac neuspesnych kol, hra konci.
Po kazdom uspesnom tahu sa vam do zasobnika pridaju pismena. Minimalne je
nutne mat v zasobniku 7 pismen. Ak je tento pocet dosiahnuty, pridaju sa vam
maximalne dve pismena, az do celkoveho maxima 15 pismen.