import java.util.ArrayList;

/**
 * Slovo identifikovane v hracej ploche hry Scrabble
 * @author Andrej Jursa
 */
public class Slovo {
	
	/**
	 * Zaciatok slova, x-ova suradnica
	 */
	private int zaciatokX = 0;
	
	/**
	 * Zaciatok slova, y-ova suradnica
	 */
	private int zaciatokY = 0;
	
	/**
	 * Koniec slova, x-ova suradnica
	 */
	private int koniecX = 0;
	
	/**
	 * Koniec slova, y-ova suradnica
	 */
	private int koniecY = 0;
	
	/**
	 * Text slova
	 */
	private String slovo = "";
	
	/**
	 * Hodnota slova
	 */
	private int hodnota = 0;
	
	/**
	 * Zoznam pouzitych novych pismen v slove
	 */
	private ArrayList<Pismeno> pouziteNovePismena = null;	
	
	/**
	 * Vytvori nove slovo
	 * @param zaciatokX x-ova suradnica zaciatku slova
	 * @param zaciatokY y-ova suradnica zaciatku slova
	 * @param koniecX x-ova suradnica konca slova
	 * @param koniecY y-ova suradnica konca slova
	 * @param slovo text slova
	 * @param hodnota hodnota slova
	 * @param pouziteNovePismena zoznam pouzitych novych pismen v slove
	 */
	public Slovo(int zaciatokX, int zaciatokY, int koniecX, int koniecY, String slovo, int hodnota, ArrayList<Pismeno> pouziteNovePismena) {
		super();
		this.zaciatokX = zaciatokX;
		this.zaciatokY = zaciatokY;
		this.koniecX = koniecX;
		this.koniecY = koniecY;
		this.slovo = slovo;
		this.hodnota = hodnota;
		this.pouziteNovePismena = pouziteNovePismena;
	}

	@Override
	public boolean equals(Object ineslovo) {
		if (ineslovo instanceof Slovo) {
			Slovo sIneslovo = (Slovo)ineslovo;
			
			if (zaciatokX == sIneslovo.zaciatokX && zaciatokY == sIneslovo.zaciatokY && koniecX == sIneslovo.koniecX && koniecY == sIneslovo.koniecY) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		int result = zaciatokX + 100 * zaciatokY + 10000 * koniecX + 1000000 * koniecY;
		return result;
	}

	/**
	 * Vrati zaciatocnu poziciu slova
	 * @return x-ova suradnica (stlpec)
	 */
	public int getZaciatokX() {
		return zaciatokX;
	}

	/**
	 * Vrati zaciatocnu poziciu slova
	 * @return y-ova suradnica (riadok)
	 */
	public int getZaciatokY() {
		return zaciatokY;
	}
	
	/**
	 * Vrati koncovu poziciu slova
	 * @return x-ova suradnica (stlpec)
	 */
	public int getKoniecX() {
		return koniecX;
	}

	/**
	 * Vrati koncovu poziciu slova
	 * @return y-ova suradnica (riadok)
	 */
	public int getKoniecY() {
		return koniecY;
	}

	/**
	 * Vrati text slova
	 * @return text slova
	 */
	public String getSlovo() {
		return slovo;
	}

	/**
	 * Vrati hodnotu slova
	 * @return hodnota slova
	 */
	public int getHodnota() {
		return hodnota;
	}

	/**
	 * Vrati zoznam pouzitych pismen (novych)
	 * @return zoznam pismen
	 */
	public ArrayList<Pismeno> getPouziteNovePismena() {
		return pouziteNovePismena;
	}
	
	@Override
	public String toString() {
		return "[" + zaciatokX + ", " + zaciatokY + "; " + koniecX + ", " + koniecY + "; " + slovo + "; " + hodnota + "; " + pouziteNovePismena.size() + "]"; 
	}
}
