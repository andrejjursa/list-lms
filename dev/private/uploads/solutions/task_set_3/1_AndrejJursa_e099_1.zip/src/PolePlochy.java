import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

/**
 * Pole plochy hry Scrabble
 * @author Andrej Jursa
 */
public class PolePlochy implements MysouOvladatelne {
	
	/**
	 * Sirka stvorca hernej plochy
	 */
	public static final int SIRKA = 40;
	/**
	 * Vyska stvorca hernej plochy
	 */
	public static final int VYSKA = 40;
	/**
	 * Rozstup na x-ovej suradnici
	 */
	public static final int ROZSTUP_X = 4;
	/**
	 * Rozstup na y-ovej suradnici
	 */
	public static final int ROZSTUP_Y = 4;
	
	/**
	 * Stlpec, ktory je zaciatocny
	 */
	public static final int ZACIATOCNA_PLOCHA_STLPEC = 7;
	
	/**
	 * Riadok, ktory je zaciatocny
	 */
	public static final int ZACIATOCNA_PLOCHA_RIADOK = 7;
	
	/**
	 * Suradnice, na ktorych umiestnene nove pismeno zarucuje dvojnasobnu hodnotu slova
	 */
	public static final int[][] DVAKRAT_HODNOTA_SLOVA = { {1, 1}, {2, 2}, {3, 3}, {4, 4}, {7, 7}, {13, 1}, {12, 2}, {11, 3}, {10, 4}, {1, 13}, {2, 12}, {3, 11}, {4, 10}, {13, 13}, {12, 12}, {11, 11}, {10, 10} };
	
	/**
	 * Suradnice, na ktorych umiestnene nove pismeno zarucuje trojnasobnu hodnotu slova
	 */
	public static final int[][] TRIKRAT_HODNOTA_SLOVA = { {0, 0}, {7, 0}, {14, 0}, {0, 7}, {14, 7}, {0, 14}, {7, 14}, {14, 14} };
	
	/**
	 * Suradnice, na ktorych umiestnene nove pismeno zarucuje dvojnasobnu hodnotu tohoto pismena
	 */
	public static final int[][] DVAKRAT_HODNOTA_PISMENA = { {3, 0}, {11, 0}, {6, 2}, {8, 2}, {0, 3}, {7, 3}, {14, 3}, {2, 6}, {6, 6}, {8, 6}, {12, 6}, {3, 7}, {11, 7}, {2, 8}, {6, 8}, {8, 8}, {12, 8}, {0, 11}, {7, 11}, {14, 11}, {6, 12}, {8, 12}, {3, 14}, {11, 14} };
	
	/**
	 * Suradnice, na ktorych umiestnene nove pismeno zarucuje trojnasobnu hodnotu tohoto pismena
	 */
	public static final int[][] TRIKRAT_HODNOTA_PISMENA = { {5, 1}, {9, 1}, {1, 5}, {5, 5}, {9, 5}, {13, 5}, {1, 9}, {5, 9}, {9, 9}, {13, 9}, {5, 13}, {9, 13} };
	
	/**
	 * Referencia na applet
	 */
	private ScrabbleApplet applet;
	
	/**
	 * Ktory je toto stlpec
	 */
	private int stlpec;
	
	/**
	 * Ktory je toto riadok
	 */
	private int riadok;
	
	/**
	 * Informacia, ci je mys nad tymto objektom
	 */
	private boolean mysNad = false;
	
	/**
	 * Pismeno leziace na tomto policku
	 */
	private Pismeno pismeno = null;
	
	/**
	 * Konstruktor
	 * @param stlpec aky je toto stlpec v hernom plane
	 * @param riadok aky je toto riadok v hernom plane
	 * @param applet referencia na applet hry
	 */
	public PolePlochy(int stlpec, int riadok, ScrabbleApplet applet) {
		this.applet = applet;
		this.stlpec = stlpec;
		this.riadok = riadok;
		
		//pismeno = new Pismeno('A', applet.getSlovnik().hodnotaZnaku('A'), applet);
	}
	
	/**
	 * Vykresli stvorec do grafickej plochy
	 * @param g graficka plocha
	 * @param odstupX odstup od bodu x = 0
	 * @param odstupY odstup od bodu y = 0
	 */
	public void paint(Graphics g, int odstupX, int odstupY) {
		int mojeX = zistiMojeX(odstupX);
		int mojeY = zistiMojeY(odstupY);
		
		Color greenColor = new Color(96, 200, 96);
		Color hodnotaSlova2krat = new Color(255, 209, 210);
		Color hodnotaSlova3krat = new Color(255, 73, 73);
		Color hodnotaPismena2krat = new Color(142, 142, 255);
		Color hodnotaPismena3krat = new Color(70, 70, 255);
		
		int mojaHodnotaSlova = hodnotaSlova();
		int mojaHodnotaPismena = hodnotaPismena();
		
		g.setColor(greenColor);
		if (mojaHodnotaSlova == 2) {
			g.setColor(hodnotaSlova2krat);
		} else if (mojaHodnotaSlova == 3) {
			g.setColor(hodnotaSlova3krat);
		} else if (mojaHodnotaPismena == 2) {
			g.setColor(hodnotaPismena2krat);
		} else if (mojaHodnotaPismena == 3) {
			g.setColor(hodnotaPismena3krat);
		}
		if (mysNad) {
			g.setColor(Color.yellow);
		}
		
		g.fillRect(mojeX, mojeY, SIRKA, VYSKA);
		g.setColor(Color.black);
		g.drawRect(mojeX - 1, mojeY - 1, SIRKA + 2, VYSKA + 2);
		g.drawRect(mojeX, mojeY, SIRKA, VYSKA);
		
		if (jeZaciatocnePolicko()) {
			g.setColor(Color.orange);
			g.fillOval(mojeX + (int)(SIRKA / 4), mojeY + (int)(VYSKA / 4), (int)(SIRKA / 2), (int)(VYSKA / 2));
		} else if (mojaHodnotaSlova >= 2) {
			g.setFont(new Font("Arial", Font.BOLD, VYSKA / 2));
			g.setColor(Color.black);
			String text = new Integer(mojaHodnotaSlova).toString() + "x";
			int textSizeX = g.getFontMetrics().stringWidth(text);
			g.drawString(text, mojeX + SIRKA - textSizeX, mojeY + VYSKA - 1);
		} else if (mojaHodnotaPismena >= 2) {
			g.setFont(new Font("Arial", Font.BOLD, VYSKA / 2));
			g.setColor(Color.black);
			String text = new Integer(mojaHodnotaPismena).toString() + "x";
			g.drawString(text, mojeX + 1, mojeY + (VYSKA / 2) - 1);
		}
		
		if (pismeno != null) {
			pismeno.paint(g, poziciaPismenaX(mojeX), poziciaPismenaY(mojeY), null);
		}
	}
	
	/**
	 * Zistuje, ci sa mys nachadza nad tymto objektom
	 * @param mysX x-ova pozicia mysi
	 * @param mysY y-ova pozicia mysi
	 * @param odstupX x-ova pozicia vzdialenosti od bodu x = 0
	 * @param odstupY y-ova pozicia vzdialenosti od bodu y = 0
	 * @return vrati <b>true</b> ak je mys nad objektom, inak <b>false</b>
	 */
	public boolean jeMysNad(int mysX, int mysY, int odstupX, int odstupY) {
		int mojeX = zistiMojeX(odstupX);
		int mojeY = zistiMojeY(odstupY);
		int mojeLaveX = mojeX + SIRKA;
		int mojeDolneY = mojeY + VYSKA;
		
		boolean stareMysNad = mysNad;
		
		if (pismeno != null && pismeno.jeMysNad(mysX, mysY, poziciaPismenaX(mojeX), poziciaPismenaY(mojeY))) {
			mysNad = false;
		} else {
			if (mysX >= mojeX && mysX <= mojeLaveX && mysY >= mojeY && mysY <= mojeDolneY) {
				mysNad = true;
			} else {
				mysNad = false;
			}
		}
		
		if (stareMysNad != mysNad) {
			applet.repaint();
		}
		
		return mysNad;
	}

	@Override
	public void klikMysou(int mysX, int mysY, int dodatocneX, int dodatocneY) {
		if (jeMysNad(mysX, mysY, dodatocneX, dodatocneY)) {
			if (applet.hracNaTahu() != null) {
				Pismeno pismenoHraca = applet.hracNaTahu().getPismenoNaUlozenie();
				if (pismenoHraca != null) {
					if (applet.mozemPolozitPismeno(stlpec, riadok)) {
						if (umiestniPismeno(pismenoHraca)) {
							applet.repaint();
						}
					}
				} else {
					if (getPismeno() != null && getPismeno().isValidovane() == false) {
						if (applet.mozemOdobratPismeno(stlpec, riadok)) {
							if (odoberPismeno()) {
								applet.repaint();
							}
						}
					}
				}
			}
		}
	}
	
	/**
	 * Vrati x-ovu suradnicu laveho horneho rohu tohoto objektu
	 * @param odstupX x-ova pozicia vzdialenosti od bodu x = 0
	 * @return x-ova suradnica
	 */
	private int zistiMojeX(int odstupX) {
		return odstupX + stlpec * SIRKA + (stlpec > 0 ? stlpec * ROZSTUP_X : 0);
	}
	
	/**
	 * Vrati y-ovu suradnicu laveho horneho rohu tohoto objektu
	 * @param odstupY y-ova pozicia vzdialenosti od bodu y = 0
	 * @return y-ova suradnica
	 */
	private int zistiMojeY(int odstupY) {
		return odstupY + riadok * VYSKA + (riadok > 0 ? riadok * ROZSTUP_Y : 0);
	}
	
	/**
	 * Vrati x-ovu poziciu, kam treba vykreslit pismeno
	 * @param mojeX x-ova pozicia tohoto objektu
	 * @return x-ova pozicia pismena
	 */
	private int poziciaPismenaX(int mojeX) {
		return mojeX + (SIRKA - Pismeno.SIRKA) / 2;
	}
	
	/**
	 * Vrati y-ovu poziciu, kam treba vykreslit pismeno
	 * @param mojeY y-ova pozicia tohoto objektu
	 * @return y-ova pozicia pismena
	 */
	private int poziciaPismenaY(int mojeY) {
		return mojeY + (VYSKA - Pismeno.VYSKA) / 2;
	}
	
	/**
	 * Vrati <b>true</b>, ak je toto policko zaciatocne
	 * @return <b>true</b>, ak je zaciatocne policko
	 */
	public boolean jeZaciatocnePolicko() {
		if (stlpec == ZACIATOCNA_PLOCHA_STLPEC && riadok == ZACIATOCNA_PLOCHA_RIADOK) {
			return true;
		}
		return false;
	}
	
	/**
	 * Vrati nasobic hodnoty slova
	 * @return vrati 1, pokial ide o bezne policko, 2 ak zdvojnasobuje hodnotu slova, alebo 3 ak ztrojnasobuje hodnotu slova
	 */
	public int hodnotaSlova() {
		for (int i = 0; i < DVAKRAT_HODNOTA_SLOVA.length; i++) {
			if (stlpec == DVAKRAT_HODNOTA_SLOVA[i][0] && riadok == DVAKRAT_HODNOTA_SLOVA[i][1]) {
				return 2;
			}
		}
		for (int i = 0; i < TRIKRAT_HODNOTA_SLOVA.length; i++) {
			if (stlpec == TRIKRAT_HODNOTA_SLOVA[i][0] && riadok == TRIKRAT_HODNOTA_SLOVA[i][1]) {
				return 3;
			}
		}
		return 1;
	}
	
	/**
	 * Vrati nasobic hodnoty pismena
	 * @return vrati 1, pokial ide o bezne policko, 2 ak zdvojnasobuje hodnotu pismena, alebo 3 ak ztrojnasobuje hodnotu pismena
	 */
	public int hodnotaPismena() {
		for (int i = 0; i < DVAKRAT_HODNOTA_PISMENA.length; i++) {
			if (stlpec == DVAKRAT_HODNOTA_PISMENA[i][0] && riadok == DVAKRAT_HODNOTA_PISMENA[i][1]) {
				return 2;
			}
		}
		for (int i = 0; i < TRIKRAT_HODNOTA_PISMENA.length; i++) {
			if (stlpec == TRIKRAT_HODNOTA_PISMENA[i][0] && riadok == TRIKRAT_HODNOTA_PISMENA[i][1]) {
				return 3;
			}
		}
		return 1;
	}
	
	/**
	 * Umiestni pismeno na hraciu plochu
	 * @param pismeno ktore bude umiestnene na toto policko hracej plochy
	 * @return vrati <b>true</b>, ak bolo pismeno umiestnene, inak vrati <b>false</b>
	 */
	public boolean umiestniPismeno(Pismeno pismeno) {
		if (this.pismeno == null && pismeno != null) {
			this.pismeno = pismeno;
			if (applet.hracNaTahu() != null) {
				applet.hracNaTahu().odoberVybranePismenoZoZasobnika();
			}
			this.pismeno.setValidovane(false);
			this.pismeno.setVyberatelne(false);
			return true;
		}
		return false;
	}
	
	public boolean odoberPismeno() {
		if (this.pismeno == null) { return false; }
		
		if (applet.hracNaTahu() != null) {
			if (applet.hracNaTahu().vlozPismenoDoZasobnika(this.pismeno)) {
				this.pismeno = null;
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * Vrati pismeno polozene na tomto policku
	 * @return pismeno
	 */
	public Pismeno getPismeno() {
		return pismeno;
	}
}
