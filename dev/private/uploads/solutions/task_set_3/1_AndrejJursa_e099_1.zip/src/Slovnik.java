import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.TreeMap;
import java.io.*;

/**
 * Slovnik pre hru Scrabble
 * @author Andrej Jursa
 */
public class Slovnik {
	
	/**
	 * Maximalna dlzka slova
	 */
	public static final int MAXIMALNA_DLZKA_SLOVA = 15;
	
	/**
	 * Minimalna dlzka slova
	 */
	public static final int MINIMALNA_DLZKA_SLOVA = 3;
	
	/**
	 * Duplikovanie samohlasok v poli pismen
	 */
	public static final int DUPLIKACIA_SAMOHLASOK = 5;
	
	/**
	 * Slovnik slov
	 */
	private HashMap<String, Boolean> slovnik;
	
	/**
	 * Mapa hodnot znakov
	 */
	private HashMap<String, Integer> hodnotaPismen;
	
	/**
	 * Pole vsetkych znakov
	 */
	private char[] znaky;
	
	/**
	 * Vytvori objekt slovnika
	 * @param cestaKSlovniku subor so slovnikom
	 * @throws FileNotFoundException ak sa subor slovnika nenajde
	 */
	public Slovnik(String cestaKSlovniku) throws FileNotFoundException {
		nacitajSlovnik(cestaKSlovniku);
	}
	
	/**
	 * Nacita slovnik so suboru
	 * @param cestaKSlovniku cesta k suboru so slovnikom
	 * @throws FileNotFoundException ak sa subor slovnika nenajde 
	 */
	private void nacitajSlovnik(String cestaKSlovniku) throws FileNotFoundException {
		slovnik = new HashMap<String, Boolean>();
		hodnotaPismen = new HashMap<String, Integer>();
		String[] samohlasky = { "A", "E", "I", "O", "U", "Y" };
		HashSet<String> mnozinaSamohlasok = new HashSet<String>();
		
		TreeMap<String, Integer> pismena = new TreeMap<String, Integer>();
		int pocetpismen = 0;
		
		File slvSubor = new File(cestaKSlovniku);
		
		FileInputStream isSubor = null;
		try {
			isSubor = new FileInputStream(slvSubor);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw e;
		}
		
		Scanner skener = new Scanner(isSubor);
		
		while (skener.hasNextLine()) {
			String slovo = skener.nextLine();
			slovo = slovo.trim().toUpperCase();
			if (slovo.length() > MAXIMALNA_DLZKA_SLOVA || slovo.length() < MINIMALNA_DLZKA_SLOVA) {
				continue;
			}
			
			for (int i = 0; i < slovo.length(); i++) {
				String znak = "" + slovo.charAt(i);
				znak = znak.toUpperCase();
				
				for (int z = 0; z < samohlasky.length; z++) {
					if (samohlasky[z].equals(znak)) {
						mnozinaSamohlasok.add(znak);
					}
				}
				
				if (pismena.containsKey(znak)) {
					pismena.put(znak, pismena.get(znak) + 1);
				} else {
					pismena.put(znak, 1);
				}
				pocetpismen++;
			}
			
			slovnik.put(slovo, true);
		}
		
		int najvacsivyskyt = 0;
		int najmensivyskyt = pocetpismen;
		for (Iterator<String> it = pismena.keySet().iterator(); it.hasNext(); ) {
			String pismeno = (String)it.next();
			Integer vyskyt = pismena.get(pismeno);
			najvacsivyskyt = Math.max(najvacsivyskyt, vyskyt);
			najmensivyskyt = Math.min(najmensivyskyt, vyskyt);
		}
		
		int max = najvacsivyskyt - najmensivyskyt;
		int celkovaReverznaHodnota = 0;
		for (Iterator<String> it = pismena.keySet().iterator(); it.hasNext(); ) {
			String pismeno = (String)it.next();
			Integer vyskyt = pismena.get(pismeno);
			int mnozina = (int)((double)(vyskyt - najmensivyskyt) / (((double)max / 9) * 10) * 10);
			hodnotaPismen.put(pismeno, 10 - mnozina);
			celkovaReverznaHodnota += mnozina + 1;
		}
				
		znaky = new char[celkovaReverznaHodnota + DUPLIKACIA_SAMOHLASOK * mnozinaSamohlasok.size()];
		int indexZnaku = 0;
		for (Iterator<String> it = pismena.keySet().iterator(); it.hasNext(); ) {
			String pismeno = (String)it.next();
			char znak = pismeno.charAt(0);
			int pocetnost = 11 - hodnotaPismen.get(pismeno);
			if (mnozinaSamohlasok.contains(pismeno)) {
				pocetnost += DUPLIKACIA_SAMOHLASOK;
			}
			for (int i = 0; i < pocetnost; i++) {
				znaky[indexZnaku] = znak;
				indexZnaku++;
			}
		}
	}
	
	/**
	 * Zisti, ci sa zadane slovo nachadza v slovniku
	 * @param slovo ktore sa bude kontrolovat
	 * @return vrati <b>true</b> ak slovo existuje slovniku, inak <b>false</b>
	 */
	public boolean existujeSlovo(String slovo) {
		if (slovnik == null) { return false; }
		
		return slovnik.containsKey(slovo.toUpperCase());
	}
	
	/**
	 * Zisti hodnotu znaku
	 * @param znak pre ktory chceme zistit hodnotu
	 * @return hodnota znaku, nula ak sa nenajde
	 */
	public int hodnotaZnaku(char znak) {
		String pismeno = "" + znak;
		pismeno = pismeno.toUpperCase();
		Integer hodnota = hodnotaPismen.get(pismeno);
		if (hodnota == null) { return 0; }
		return hodnota;
	}
	
	/**
	 * Vrati nahodny znak z mnoziny znakov slovnika
	 * @return znak
	 */
	public char nahodnyZnak() {
		Random generator = new Random();
		int indexZnaku = generator.nextInt(znaky.length);
		return znaky[indexZnaku];
	}
}
