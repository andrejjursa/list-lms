import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;

import javax.swing.*;

/**
 * Applet pre Scrabble
 * @author Andrej Jursa
 */
public class ScrabbleApplet extends JApplet implements MouseMotionListener, MouseListener {
	
	/**
	 * Vychodzie seriove cislo
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Pocet stlpcov v ploche
	 */
	public static final int POCET_STLPCOV_PLOCHY = 15;
	
	/**
	 * Pocet riadkov v ploche
	 */
	public static final int POCET_RIADKOV_PLOCHY = 15;
	
	/**
	 * Minimalny pocet pismen, ktore musi mat hrac v zasobniku
	 */
	public static final int MIN_POCET_PISMEN_V_ZASOBNIKU = 7;
	
	/**
	 * Maximalny mozny pocet pismen, ktore mozu byt v hracovom zasobniku
	 */
	public static final int MAX_POCET_PISMEN_V_ZASOBNIKU = 15;
	
	/**
	 * Odstadenie stvorcovej plochy zhora
	 */
	public static final int ODSADENIE_PLOCHY_ZHORA = 40;
	
	/**
	 * Odsadenie stvorcovej plochy zlava
	 */
	public static final int ODSADENIE_PLOCHY_ZLAVA = 10;
	
	/**
	 * Odsadenie informacneho panela zlava
	 */
	public static final int ODSADENIE_INFOPANELA_ZLAVA = 10;
	
	/**
	 * Odsadenie informacneho panela zhora
	 */
	public static final int ODSADENIE_INFOPANELA_ZHORA = 30;
	
	/**
	 * Velkost pisma pre meno hraca
	 */
	public static final int INFOPANEL_VELKOST_PISMA_HRAC = 20;
	
	/**
	 * Velkost pisma pre skore hraca
	 */
	public static final int INFOPANEL_VELKOST_PISMA_SKORE = 15;
	
	/**
	 * Velkost pisma v tabulke hracov
	 */
	public static final int TABULKA_HRACOV_VELKOST_PISMA = 12;
	
	/**
	 * Odsadenie panela s pismenami zlava
	 */
	public static final int ODSADENIE_PANELA_PISMEN_ZLAVA = 10;
	
	/**
	 * Odsadenie panela s pismenami zhora
	 */
	public static final int ODSADENIE_PANELA_PISMEN_ZHORA = ODSADENIE_PLOCHY_ZHORA + POCET_RIADKOV_PLOCHY * PolePlochy.VYSKA + (POCET_RIADKOV_PLOCHY - 1) * PolePlochy.ROZSTUP_Y + 10;
	
	/**
	 * Maximalny povoleny pocet neuspesnych kol, ktore musi splnit kazdy hrac a dojde ku koncu hry
	 */
	public static final int MAXIMALNY_POCET_NEUSPESNYCH_KOL = 2;
	
	/**
	 * Cesta k slovniku
	 */
	private String cestaKSlovniku = "./slovnik.txt";
	
	/**
	 * Spustenie behu programu po inicializacii
	 */
	private Boolean programBezi = false;
	
	/**
	 * Semafor na synchronizaciu plochy
	 */
	private MikroSemafor semaforSynchronizaciePlochy = null;
	
	/**
	 * Slovnik
	 */
	private Slovnik slovnik = null;
	
	/**
	 * Pole hracov
	 */
	private Hrac[] hraci = null;
	
	/**
	 * Index hraca na tahu
	 */
	private int hracNaTahu = 0;
	
	/**
	 * Herne pole
	 */
	private PolePlochy[][] plocha = null;
	
	/**
	 * Tlacidla
	 */
	private Tlacidlo[] tlacidla = null;
	
	/**
	 * Odsadenie panela hracov z hora
	 */
	private int odsadeniePanelaHracovZhora = 0;
	
	@Override
	public void init() {
		super.init();
		
		semaforSynchronizaciePlochy = new MikroSemafor();
		
		try {
			slovnik = new Slovnik(cestaKSlovniku);
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(this, "Subor slovnika sa nepodarilo najst. Program teraz skonci.");
			System.exit(1);
		} 
		
		vytvorTlacidla();
		
		vygenerujPlochu();
		
		addMouseMotionListener(this);
		addMouseListener(this);
	}
	
	@Override
	public void start() {
		super.start();
		
		programBezi = true;
	}
	
	@Override
	public void update(Graphics g) {
		paint(g);
	}
	
	@Override
	public void paint(Graphics g) {
		if (!programBezi) { return; }  
		
		BufferedImage img = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
		
		Graphics gr = img.getGraphics();
		
		gr.setColor(Color.white);
		gr.fillRect(0, 0, getWidth(), getHeight());
		
		synchronized (semaforSynchronizaciePlochy) {
			for (int stlpec=0; stlpec < POCET_STLPCOV_PLOCHY; stlpec++) {
				for (int riadok=0; riadok < POCET_RIADKOV_PLOCHY; riadok++) {
					plocha[stlpec][riadok].paint(gr, ODSADENIE_PLOCHY_ZLAVA, ODSADENIE_PLOCHY_ZHORA);
				}
			}
		}
		
		renderujStavovyRiadok(gr);
		
		if (hracNaTahu() != null) {
			hracNaTahu().paint(gr);
		}
		
		if (tlacidla != null) {
			for (int i = 0; i < tlacidla.length; i++) {
				tlacidla[i].paint(gr);
			}
		}
		
		tabulkaHracov(gr);
		
		g.drawImage(img, 0, 0, this);
	}
	
	/**
	 * Zobrazi tabulku hracov
	 * @param g graficka plocha
	 */
	private void tabulkaHracov(Graphics g) {
		if (hraci == null || hraci.length == 0) { return; }
		int odsadenieZLava = ODSADENIE_PLOCHY_ZLAVA + 10 + POCET_STLPCOV_PLOCHY * PolePlochy.SIRKA + (POCET_STLPCOV_PLOCHY - 1) * PolePlochy.ROZSTUP_X;
		int pomocneOdsadenieZhora = 0;
		
		for (int i = 0; i < hraci.length; i++) {
			g.setFont(new Font("Arial", Font.BOLD, TABULKA_HRACOV_VELKOST_PISMA));
			String text = hraci[i].getMeno();
			Rectangle2D rozmery = g.getFontMetrics().getStringBounds(text, g);
			g.setColor(hraci[i].getFarba());
			g.drawString(text, odsadenieZLava, odsadeniePanelaHracovZhora + pomocneOdsadenieZhora + (int)rozmery.getHeight());
			pomocneOdsadenieZhora += (int)rozmery.getHeight() + 2;
			
			int pomocneOdsadenieZlava = 0;
			g.setFont(new Font("Arial", Font.PLAIN, TABULKA_HRACOV_VELKOST_PISMA));
			text = "Sk�re: ";
			rozmery = g.getFontMetrics().getStringBounds(text, g);
			g.setColor(Color.black);
			g.drawString(text, odsadenieZLava, odsadeniePanelaHracovZhora + pomocneOdsadenieZhora + (int)rozmery.getHeight());
			pomocneOdsadenieZlava = (int)rozmery.getWidth();
			
			g.setFont(new Font("Arial", Font.BOLD, TABULKA_HRACOV_VELKOST_PISMA));
			text = Integer.toString(hraci[i].getSkore());
			g.setColor(hraci[i].getFarba());
			g.drawString(text, odsadenieZLava + pomocneOdsadenieZlava, odsadeniePanelaHracovZhora + pomocneOdsadenieZhora + (int)rozmery.getHeight());
			pomocneOdsadenieZhora += (int)rozmery.getHeight() + 2;
			
			g.setFont(new Font("Arial", Font.PLAIN, TABULKA_HRACOV_VELKOST_PISMA));
			text = "Ne�sp. kol�: ";
			rozmery = g.getFontMetrics().getStringBounds(text, g);
			g.setColor(Color.black);
			g.drawString(text, odsadenieZLava, odsadeniePanelaHracovZhora + pomocneOdsadenieZhora + (int)rozmery.getHeight());
			pomocneOdsadenieZlava = (int)rozmery.getWidth();
			
			g.setFont(new Font("Arial", Font.BOLD, TABULKA_HRACOV_VELKOST_PISMA));
			text = Integer.toString(hraci[i].getNeuspesneKola());
			g.setColor(hraci[i].getFarba());
			g.drawString(text, odsadenieZLava + pomocneOdsadenieZlava, odsadeniePanelaHracovZhora + pomocneOdsadenieZhora + (int)rozmery.getHeight());
			pomocneOdsadenieZhora += (int)rozmery.getHeight() + 2;
		}
	}
	
	private void vytvorTlacidla() {
		int odsadenie_zlava = ODSADENIE_PLOCHY_ZLAVA + 10 + POCET_STLPCOV_PLOCHY * PolePlochy.SIRKA + (POCET_STLPCOV_PLOCHY - 1) * PolePlochy.ROZSTUP_X;
		int odsadenie_zhora = 0;
		final ScrabbleApplet applet = this;
		
		tlacidla = new Tlacidlo[3];
		tlacidla[0] = new Tlacidlo("�al�� hr��", 32, 96, odsadenie_zlava, ODSADENIE_PLOCHY_ZHORA + odsadenie_zhora, this);
		tlacidla[0].setUdalost(new UdalostTlacidla() {
			
			@Override
			public void vykonaj() {
				if (applet.hracNaTahu() != null) {
					int celkoveSkore = spocitajSkoreAValidujPismena();
					if (celkoveSkore == 0) {
						int odpoved = JOptionPane.showConfirmDialog(applet, "Bohu�ial, nepodarilo sa V�m vytvori� �iadne slovo, chcete zopakova� �ah?", "Scrabble", JOptionPane.YES_NO_OPTION);
						if (odpoved == 0) { return; }
						applet.hracNaTahu().zvisNeuspesneKola();
					} else {
						applet.hracNaTahu().resetujNeuspesneKola();
						applet.hracNaTahu().addScore(celkoveSkore);
						applet.hracNaTahu().pridajPismenaDoZasobniku();
					}
					applet.dalsiHrac();
					applet.repaint();
					applet.otestujAUkonciHru();
				} else {
					JOptionPane.showMessageDialog(applet, "Hra nie je spusten�!", "Scrabble", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		});
		odsadenie_zhora += 10 + 32;
		
		tlacidla[1] = new Tlacidlo("V�mena", 32, 96, odsadenie_zlava, ODSADENIE_PLOCHY_ZHORA + odsadenie_zhora, this);
		tlacidla[1].setUdalost(new UdalostTlacidla() {
			
			@Override
			public void vykonaj() {
				if (applet.hracNaTahu() != null) {
					int odpoved = JOptionPane.showConfirmDialog(applet, "Naozaj chce� ukon�i� tah a vymeni� v�etky svoje p�smen�?\nOdober� sa aj v�etky nepotvrden� p�smen� na hracom pl�ne.", "Scrabble", JOptionPane.YES_NO_OPTION);
					if (odpoved == 0) {
						applet.vymenVsetkyPismena();
						applet.hracNaTahu().zvisNeuspesneKola();
						applet.dalsiHrac();
						applet.repaint();
					}
					applet.otestujAUkonciHru();
				} else {
					JOptionPane.showMessageDialog(applet, "Hra nie je spusten�!", "Scrabble", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		});
		odsadenie_zhora += 10 + 32;
		
		tlacidla[2] = new Tlacidlo("Nov� hra", 32, 96, odsadenie_zlava, ODSADENIE_PLOCHY_ZHORA + odsadenie_zhora, this);
		tlacidla[2].setUdalost(new UdalostTlacidla() {
			
			@Override
			public void vykonaj() {
				int odpoved = 0;
				if (hraci != null && hraci.length > 0) {
					odpoved = JOptionPane.showConfirmDialog(applet, "Naozaj chcete za�a� nov� hru?", "Scrabble", JOptionPane.YES_NO_OPTION);
				}
				if (odpoved == 0) {
					applet.vytvorNovuHru();
					applet.repaint();
				}
			}
			
		});
		odsadenie_zhora += 10 + 32;
		
		odsadeniePanelaHracovZhora = ODSADENIE_PLOCHY_ZHORA + odsadenie_zhora;
	}
	
	/**
	 * Vymeni vsetky pismena v zasobniku hracovi na tahu
	 */
	private void vymenVsetkyPismena() {
		if (hracNaTahu() == null) { return; }
		synchronized (semaforSynchronizaciePlochy) {
			for (int stlpec = 0; stlpec < POCET_STLPCOV_PLOCHY; stlpec++) {
				for (int riadok = 0; riadok < POCET_RIADKOV_PLOCHY; riadok++) {
					if (plocha[stlpec][riadok].getPismeno() != null && plocha[stlpec][riadok].getPismeno().isValidovane() == false) {
						plocha[stlpec][riadok].odoberPismeno();
					}
				}
			}
		}
		
		hracNaTahu().vymenPismenaVZasobniku();
	}
	
	/**
	 * Vyrenderuje hracov stavovy riadok
	 * @param g graficka plocha
	 */
	private void renderujStavovyRiadok(Graphics g) {
		String text = "Hr��: ";
		int dodatocneOdsadenie = 0;
		g.setColor(Color.black);
		g.setFont(new Font("Arial", Font.PLAIN, INFOPANEL_VELKOST_PISMA_HRAC));
		g.drawString(text, ODSADENIE_INFOPANELA_ZLAVA + dodatocneOdsadenie, ODSADENIE_INFOPANELA_ZHORA);
		dodatocneOdsadenie += g.getFontMetrics().stringWidth(text);
		Hrac hrac = hracNaTahu();
		if (hrac != null) {
			text = hrac.getMeno(); 
			g.setColor(hrac.getFarba());
			g.setFont(new Font("Arial", Font.BOLD, INFOPANEL_VELKOST_PISMA_HRAC));
		} else {
			text = "Neexistuje hr��!"; 
			g.setColor(Color.black);
			g.setFont(new Font("Arial", Font.BOLD, INFOPANEL_VELKOST_PISMA_HRAC));
		}
		text += " ";
		g.drawString(text, ODSADENIE_INFOPANELA_ZLAVA + dodatocneOdsadenie, ODSADENIE_INFOPANELA_ZHORA);
		dodatocneOdsadenie += g.getFontMetrics().stringWidth(text);
		text = "Sk�re: ";
		g.setColor(Color.black);
		g.setFont(new Font("Arial", Font.PLAIN, INFOPANEL_VELKOST_PISMA_SKORE));
		g.drawString(text, ODSADENIE_INFOPANELA_ZLAVA + dodatocneOdsadenie, ODSADENIE_INFOPANELA_ZHORA);
		dodatocneOdsadenie += g.getFontMetrics().stringWidth(text);
		int skore = 0;
		if (hrac != null) {
			skore = hrac.getSkore();
			text = Integer.toString(skore);
			g.setColor(hrac.getFarba());
		} else {
			text = Integer.toString(skore);
			g.setColor(Color.black);
		}
		g.setFont(new Font("Arial", Font.BOLD, INFOPANEL_VELKOST_PISMA_SKORE));
		text += " ";
		g.drawString(text, ODSADENIE_INFOPANELA_ZLAVA + dodatocneOdsadenie, ODSADENIE_INFOPANELA_ZHORA);
		dodatocneOdsadenie += g.getFontMetrics().stringWidth(text);
		switch (skore) {
			case 1: text = "bod"; break;
			case 2:
			case 3:
			case 4: text = "body"; break;
			default: text = "bodov"; break;
		}
		text += " ";
		g.setColor(Color.black);
		g.setFont(new Font("Arial", Font.PLAIN, INFOPANEL_VELKOST_PISMA_SKORE));
		g.drawString(text, ODSADENIE_INFOPANELA_ZLAVA + dodatocneOdsadenie, ODSADENIE_INFOPANELA_ZHORA);
		dodatocneOdsadenie += g.getFontMetrics().stringWidth(text);
		text = "Po�et ne�spe�n�ch k�l: ";
		g.setColor(Color.black);
		g.setFont(new Font("Arial", Font.PLAIN, INFOPANEL_VELKOST_PISMA_SKORE));
		g.drawString(text, ODSADENIE_INFOPANELA_ZLAVA + dodatocneOdsadenie, ODSADENIE_INFOPANELA_ZHORA);
		dodatocneOdsadenie += g.getFontMetrics().stringWidth(text);
		if (hrac == null) {
			text = "-";
			g.setColor(Color.black);
		} else {
			text = Integer.toString(hrac.getNeuspesneKola());
			g.setColor(hrac.getFarba());
		}
		g.setFont(new Font("Arial", Font.BOLD, INFOPANEL_VELKOST_PISMA_SKORE));
		g.drawString(text, ODSADENIE_INFOPANELA_ZLAVA + dodatocneOdsadenie, ODSADENIE_INFOPANELA_ZHORA);
		dodatocneOdsadenie += g.getFontMetrics().stringWidth(text);
	}
	
	/**
	 * Vytvori novu hru
	 */
	public void vytvorNovuHru() {
		
		try {
			vytvorHracov();
		} catch (NewGameCancelException e) {
			return;
		}
		
		vygenerujPlochu();
	}
	
	/**
	 * Nastavi cestu k slovniku
	 * @param cestaKSlovniku spolu s menom suboru
	 */
	public void setCestaKSlovniku(String cestaKSlovniku) {
		this.cestaKSlovniku = cestaKSlovniku;
	}
	
	/**
	 * Vygeneruje plochu
	 */
	synchronized
	private void vygenerujPlochu() {
		synchronized (semaforSynchronizaciePlochy) {
			plocha = new PolePlochy[POCET_STLPCOV_PLOCHY][POCET_RIADKOV_PLOCHY];
			
			for (int stlpec=0; stlpec < POCET_STLPCOV_PLOCHY; stlpec++) {
				for (int riadok=0; riadok < POCET_RIADKOV_PLOCHY; riadok++) {
					plocha[stlpec][riadok] = new PolePlochy(stlpec, riadok, this);
				}
			}
		}
	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		if (!programBezi) { return; }
		
		int mysX = arg0.getX();
		int mysY = arg0.getY();
		
		testMysiNadObjektorm(mysX, mysY);
	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		if (!programBezi) { return; }
		
		int mysX = arg0.getX();
		int mysY = arg0.getY();
		
		testMysiNadObjektorm(mysX, mysY);
	}
	
	private void testMysiNadObjektorm(int mysX, int mysY) {
		if (tlacidla != null) {
			for (int i = 0; i < tlacidla.length; i++) {
				if (tlacidla[i].jeMysNad(mysX, mysY, 0, 0)) {
					mysX = Integer.MIN_VALUE;
					mysY = Integer.MIN_VALUE;
				}
			}
		}
		
		vysvietHernyStvorecAkJeNadNimMys(mysX, mysY);
		
		if (hracNaTahu() != null) {
			hracNaTahu().jeMysNad(mysX, mysY, 0, 0);
		}
	}
	
	private void vysvietHernyStvorecAkJeNadNimMys(int mysX, int mysY) {
		synchronized (semaforSynchronizaciePlochy) {
			for (int stlpec=0; stlpec < POCET_STLPCOV_PLOCHY; stlpec++) {
				for (int riadok=0; riadok < POCET_RIADKOV_PLOCHY; riadok++) {
					plocha[stlpec][riadok].jeMysNad(mysX, mysY, ODSADENIE_PLOCHY_ZLAVA, ODSADENIE_PLOCHY_ZHORA);
				}
			}
		}
	}
	
	/**
	 * Vrati slovnik
	 * @return slovnik
	 */
	public Slovnik getSlovnik() {
		return slovnik;
	}
	
	/**
	 * Vytvori hracov
	 * @throws NewGameCancelException nastava, ak sa vytvara nova hra a tento proces je preruseny
	 */
	private void vytvorHracov() throws NewGameCancelException {
		int pocetHracov = 2;
		for (;;) {
			String pocetHracovStr = JOptionPane.showInputDialog(null, "Zadajte, pros�m, po�et hr��ov v rozsahu 2 a� 4:", "Scrabble", JOptionPane.QUESTION_MESSAGE);
			if (pocetHracovStr == null) { 
				zobrazDialogUkonceniaVytvaraniaHry();
				continue; 
			} else {
				try {
					pocetHracov = Integer.valueOf(pocetHracovStr);
				} catch (NumberFormatException e) {
					pocetHracov = 0;
				}
				if (pocetHracov >= 2 && pocetHracov <= 4) {
					break;
				}
			}
		}
		
		String[] menaHracov = new String[pocetHracov];
		
		for (int index = 0; index < pocetHracov; index++) {
			zadanieMena:
			for (;;) {
				String menoHraca = JOptionPane.showInputDialog(null, "Zadajte meno hr��a " + Integer.toString(index + 1) + " (1 a� 20 znakov):", "Scrabble", JOptionPane.QUESTION_MESSAGE);
				if (menoHraca == null) {
					zobrazDialogUkonceniaVytvaraniaHry();
					continue zadanieMena;
				} else {
					menoHraca = menoHraca.trim();
					if (menoHraca.length() > 0 && menoHraca.length() <= 20) {
						menaHracov[index] = menoHraca;
						break zadanieMena;
					}
				}
			}
		}
		
		hraci = new Hrac[pocetHracov];
		
		Color[] farby = { Color.blue, Color.red, Color.orange, Color.green };
		
		for (int index = 0; index < pocetHracov; index++) {
			hraci[index] = new Hrac(menaHracov[index], farby[index], this);
		}
		
		hracNaTahu = 0;
	}
	
	/**
	 * Zobrazi ukoncovaci dialog pri vytvarani hry
	 * @throws NewGameCancelException nastava, ak sa vytvara nova hra a tento proces je preruseny
	 */
	private void zobrazDialogUkonceniaVytvaraniaHry() throws NewGameCancelException {
		int odpoved = JOptionPane.showConfirmDialog(null, "Chcete ukon�i� vytv�ranie novej hry?", "Scrabble", JOptionPane.YES_NO_OPTION);
		System.out.println(odpoved);
		if (odpoved == 0) {
			throw new NewGameCancelException();
		}
	}
	
	/**
	 * Vrati hraca, ktory je prave na tahu
	 * @return <b>null</b> alebo hrac na tahu
	 */
	public Hrac hracNaTahu() {
		if (hraci == null || hraci.length == 0) { return null; }
		try {
			return hraci[hracNaTahu];
		} catch (ArrayIndexOutOfBoundsException e) {
			System.err.println("Nemozem najst hraca s indexom: " + hracNaTahu);
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Posunie dalsieho hraca na tah
	 */
	private void dalsiHrac() {
		if (hraci == null || hraci.length == 0) { return; }
		
		if (hracNaTahu() != null) {
			hracNaTahu().zrusVyberPismena();
		}
		
		hracNaTahu = (hracNaTahu + 1) % hraci.length;
	}
	
	/**
	 * Zisti, ci je mozne pokladat nove pismeno na plochu s danym cislom stlpca a riadku
	 * @param stlpec policka v ploche
	 * @param riadok policka v ploche
	 * @return <b>true</b>, ak je mozne na tuto poziciu polozit pismeno
	 */
	public boolean mozemPolozitPismeno(int stlpec, int riadok) {
		if (stlpec >= 0 && stlpec < POCET_STLPCOV_PLOCHY && riadok >= 0 && riadok < POCET_RIADKOV_PLOCHY) {
			int pocetUlozenychPismen = 0;
			for (int i_stlpec = 0; i_stlpec < POCET_STLPCOV_PLOCHY; i_stlpec++) {
				for (int i_riadok = 0; i_riadok < POCET_RIADKOV_PLOCHY; i_riadok++) {
					if (plocha[i_stlpec][i_riadok].getPismeno() != null) {
						pocetUlozenychPismen++;
					}
				}
			}
			
			if (pocetUlozenychPismen == 0) {
				return plocha[stlpec][riadok].jeZaciatocnePolicko();
			}
			
			if (plocha[stlpec][riadok].getPismeno() != null) { return false; }
			
			boolean jeMoznePolozit = false;
			
			if (stlpec > 0) {
				if (plocha[stlpec - 1][riadok].getPismeno() != null) { jeMoznePolozit = true; }
			}
			if (stlpec < POCET_STLPCOV_PLOCHY - 1) {
				if (plocha[stlpec + 1][riadok].getPismeno() != null) { jeMoznePolozit = true; }
			}
			if (riadok > 0) {
				if (plocha[stlpec][riadok - 1].getPismeno() != null) { jeMoznePolozit = true; }
			}
			if (riadok < POCET_RIADKOV_PLOCHY - 1) {
				if (plocha[stlpec][riadok + 1].getPismeno() != null) { jeMoznePolozit = true; }
			}
				
			return jeMoznePolozit;
		}
		return false;
	}
	
	/**
	 * Urci, ci je mozne odobrat pismeno z hracieho planu
	 * @param stlpec v ktorom sa pismeno nachadza
	 * @param riadok v ktorom sa pismeno nachadza
	 * @return vrati <b>true</b>, ak je mozne pismeno odobrat
	 */
	public boolean mozemOdobratPismeno(int stlpec, int riadok) {
		if (stlpec >= 0 && stlpec < POCET_STLPCOV_PLOCHY && riadok >= 0 && riadok < POCET_RIADKOV_PLOCHY) {
			Pismeno pismeno = plocha[stlpec][riadok].getPismeno();
			if (pismeno == null || pismeno.isValidovane() == true) {
				return false;
			}
			
			int pocetUlozenychPismen = 0;
			for (int i_stlpec = 0; i_stlpec < POCET_STLPCOV_PLOCHY; i_stlpec++) {
				for (int i_riadok = 0; i_riadok < POCET_RIADKOV_PLOCHY; i_riadok++) {
					if (plocha[i_stlpec][i_riadok].getPismeno() != null) {
						pocetUlozenychPismen++;
					}
				}
			}
			
			if (plocha[stlpec][riadok].jeZaciatocnePolicko() && pocetUlozenychPismen != 1) {
				return false;
			} else if (plocha[stlpec][riadok].jeZaciatocnePolicko() && pocetUlozenychPismen == 1) {
				return true;
			}
			
			HashSet<PolePlochy> navstivene = new HashSet<PolePlochy>();
			navstivene.add(plocha[stlpec][riadok]);
			
			LinkedList<Pair<Integer, Integer>> zasobnikPolicok = new LinkedList<Pair<Integer,Integer>>();
			
			int pocetSamostatnychUtvarov = 0;
			for (int i_stlpec = 0; i_stlpec < POCET_STLPCOV_PLOCHY; i_stlpec++) {
				for (int i_riadok = 0; i_riadok < POCET_RIADKOV_PLOCHY; i_riadok++) {
					if (plocha[i_stlpec][i_riadok].getPismeno() != null && !navstivene.contains(plocha[i_stlpec][i_riadok])) {
						pocetSamostatnychUtvarov++;
						zasobnikPolicok.addLast(new Pair<Integer, Integer>(i_stlpec, i_riadok));
						while (zasobnikPolicok.size() > 0) {
							Pair<Integer, Integer> suradnice = zasobnikPolicok.pollFirst();
							int l_stlpec = suradnice.getValue1();
							int l_riadok = suradnice.getValue2();
							if (!navstivene.contains(plocha[l_stlpec][l_riadok])) {
								navstivene.add(plocha[l_stlpec][l_riadok]);
								
								if (l_stlpec > 0) {
									if (plocha[l_stlpec - 1][l_riadok].getPismeno() != null) {
										zasobnikPolicok.addLast(new Pair<Integer, Integer>(l_stlpec - 1, l_riadok));
									}
								}
								if (l_stlpec < POCET_STLPCOV_PLOCHY - 1) {
									if (plocha[l_stlpec + 1][l_riadok].getPismeno() != null) {
										zasobnikPolicok.addLast(new Pair<Integer, Integer>(l_stlpec + 1, l_riadok));
									}
								}
								if (l_riadok > 0) {
									if (plocha[l_stlpec][l_riadok - 1].getPismeno() != null) {
										zasobnikPolicok.addLast(new Pair<Integer, Integer>(l_stlpec, l_riadok - 1));
									}
								}
								if (l_riadok < POCET_RIADKOV_PLOCHY - 1) {
									if (plocha[l_stlpec][l_riadok + 1].getPismeno() != null) {
										zasobnikPolicok.addLast(new Pair<Integer, Integer>(l_stlpec, l_riadok + 1));
									}
								}
							}
						}
					}
				}
			}
			
			if (pocetSamostatnychUtvarov != 1) {
				return false;
			}
			
			return true;
		}
		return false;
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		if (!programBezi) { return; }
		
		int mysX = arg0.getX();
		int mysY = arg0.getY();
		
		if (tlacidla != null) {
			for (int i = 0; i < tlacidla.length; i++) {
				tlacidla[i].klikMysou(mysX, mysY, 0, 0);
			}
		}
		
		klikniNaHernyStvorcek(mysX, mysY);
		
		if (hracNaTahu() != null) {
			hracNaTahu().klikMysou(mysX, mysY, 0, 0);
		}
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}
	
	/**
	 * Udalost kliknutia na nejaky z hernych stvorcov
	 * @param mysX x-ova suradnica mysi
	 * @param mysY y-ova suradnica mysi
	 */
	private void klikniNaHernyStvorcek(int mysX, int mysY) {
		synchronized (semaforSynchronizaciePlochy) {
			for (int stlpec=0; stlpec < POCET_STLPCOV_PLOCHY; stlpec++) {
				for (int riadok=0; riadok < POCET_RIADKOV_PLOCHY; riadok++) {
					plocha[stlpec][riadok].klikMysou(mysX, mysY, ODSADENIE_PLOCHY_ZLAVA, ODSADENIE_PLOCHY_ZHORA);
				}
			}
		}
	}
	
	/**
	 * Vrati pocet nezvalidovanych, tj. novych, pismen v ploche
	 * @return pocet takych pismen
	 */
	public int pocetNovychPismenVPloche() {
		int pocet = 0;
		synchronized (semaforSynchronizaciePlochy) {
			for (int stlpec=0; stlpec < POCET_STLPCOV_PLOCHY; stlpec++) {
				for (int riadok=0; riadok < POCET_RIADKOV_PLOCHY; riadok++) {
					if (plocha[stlpec][riadok].getPismeno() != null && plocha[stlpec][riadok].getPismeno().isValidovane() == false) {
						pocet++;
					}
				}
			}
		}
		return pocet;
	}
	
	/**
	 * Pre aktualneho hraca spocita skore a zvaliduje pismena, nepouzitelne pismena vrati naspat hracovi do zasobnika
	 * @return celkove skore za nove slova
	 */
	public int spocitajSkoreAValidujPismena() {
		int skore = 0;
		
		HashSet<Slovo> slova = najdiNoveSlova();

		String spravneSlova = "";
		String delimiter = "";
		
		for (Slovo slovo: slova) {
			skore += slovo.getHodnota();
			spravneSlova += delimiter + slovo.getSlovo();
			delimiter = ", ";
			
			ArrayList<Pismeno> pouziteNovePismena = slovo.getPouziteNovePismena();
			for (Pismeno pismeno: pouziteNovePismena) {
				pismeno.setValidovane(true);
			}
		}
		
		synchronized (semaforSynchronizaciePlochy) {
			for (int stlpec=0; stlpec < POCET_STLPCOV_PLOCHY; stlpec++) {
				for (int riadok=0; riadok < POCET_RIADKOV_PLOCHY; riadok++) {
					if (plocha[stlpec][riadok].getPismeno() != null && plocha[stlpec][riadok].getPismeno().isValidovane() == false) {
						plocha[stlpec][riadok].odoberPismeno();
					}
				}
			}
		}
		
		if (hracNaTahu()  != null) {
			if (hracNaTahu().pocetPismenVZasobniku() == 0) {
				skore += 50;
			}
		}
		
		if (!otestujIntegrituHry()) {
			for (Slovo slovo: slova) {
				
				ArrayList<Pismeno> pouziteNovePismena = slovo.getPouziteNovePismena();
				for (Pismeno pismeno: pouziteNovePismena) {
					pismeno.setValidovane(false);
				}
			}
			
			synchronized (semaforSynchronizaciePlochy) {
				for (int stlpec=0; stlpec < POCET_STLPCOV_PLOCHY; stlpec++) {
					for (int riadok=0; riadok < POCET_RIADKOV_PLOCHY; riadok++) {
						if (plocha[stlpec][riadok].getPismeno() != null && plocha[stlpec][riadok].getPismeno().isValidovane() == false) {
							plocha[stlpec][riadok].odoberPismeno();
						}
					}
				}
			}
			
			skore = 0;
		} else {
			if (skore > 0) {
				JOptionPane.showMessageDialog(this, "Vytvoren� slovo(�): " + spravneSlova + ". Celkov� hodnota " + Integer.toString(skore) + " bodov.", "Scrabble", JOptionPane.INFORMATION_MESSAGE);
			}
		}
		
		return skore;
	}
	
	/**
	 * Vytvori zoznam novych slov
	 * @return zoznam novych slov
	 */
	public HashSet<Slovo> najdiNoveSlova() {
		HashSet<Slovo> noveSlova = new HashSet<Slovo>();
		
		if (pocetNovychPismenVPloche() == 0) { return noveSlova; }
//		System.out.println("PocetNovychPismen: " + pocetNovychPismenVPloche()); // DEBUG
		
		synchronized (semaforSynchronizaciePlochy) {
			for (int stlpec=0; stlpec < POCET_STLPCOV_PLOCHY; stlpec++) {
				for (int riadok=0; riadok < POCET_RIADKOV_PLOCHY; riadok++) {
					if (plocha[stlpec][riadok].getPismeno() != null && plocha[stlpec][riadok].getPismeno().isValidovane() == false) {
//						System.out.println("Nove pismeno na " + stlpec + ", " + riadok); // DEBUG
						Slovo slovoVRiadku = najdiSlovoVRiadku(stlpec, riadok);
						Slovo slovoVStlpci = najdiSlovoVStlpci(stlpec, riadok);
//						System.out.println("V riadku: " + slovoVRiadku);
//						System.out.println("V stlpci: " + slovoVStlpci);
						if (slovoVRiadku != null && noveSlova.add(slovoVRiadku)) {
//							System.out.println(slovoVRiadku.getSlovo() + " (" + slovoVRiadku.getHodnota() + ")");
						}
						if (slovoVStlpci != null && noveSlova.add(slovoVStlpci)) {
//							System.out.println(slovoVStlpci.getSlovo() + " (" + slovoVStlpci.getHodnota() + ")");
						}
					}
				}
			}
		}
		
		return noveSlova;
	}
	
	/**
	 * Najde nove slovo, ktore lezi v riadku na danych suradniciach
	 * @param stlpec v hernej ploche
	 * @param riadok v hernej ploche
	 * @return {@link Slovo} alebo <b>null</b>
	 */
	public Slovo najdiSlovoVRiadku(int stlpec, int riadok) {
		if (plocha[stlpec][riadok].getPismeno() == null || plocha[stlpec][riadok].getPismeno().isValidovane() == true) {
			return null;
		}
		
		int nasobicHodnotySlova = 1;
		int hodnotaSlova = 0;
		String text = "";
		int zaciatokX = stlpec;
		int zaciatokY = riadok;
		int koniecX = stlpec;
		int koniecY = riadok;
		ArrayList<Pismeno> pouziteNovePismena = new ArrayList<Pismeno>();
		
		for (int x = stlpec; x >= 0; x--) {
			if (plocha[x][riadok].getPismeno() == null) {
				break;
			}
			zaciatokX = x;
			
			int nasobicHodnotyPismena = 1;
			
			Pismeno pismeno = plocha[x][riadok].getPismeno();
			
			if (pismeno.isValidovane() == false) {
				nasobicHodnotyPismena = Math.max(plocha[x][riadok].hodnotaPismena(), nasobicHodnotyPismena);
				nasobicHodnotySlova = Math.max(plocha[x][riadok].hodnotaSlova(), nasobicHodnotySlova);
				pouziteNovePismena.add(pismeno);
			}
			
			hodnotaSlova += pismeno.getHodnota() * nasobicHodnotyPismena;
		}
		for (int x = stlpec+1; x < POCET_STLPCOV_PLOCHY; x++) {
			if (plocha[x][riadok].getPismeno() == null) {
				break;
			}
			koniecX = x;
			
			int nasobicHodnotyPismena = 1;
			
			Pismeno pismeno = plocha[x][riadok].getPismeno();
			
			if (pismeno.isValidovane() == false) {
				nasobicHodnotyPismena = Math.max(plocha[x][riadok].hodnotaPismena(), nasobicHodnotyPismena);
				nasobicHodnotySlova = Math.max(plocha[x][riadok].hodnotaSlova(), nasobicHodnotySlova);
				pouziteNovePismena.add(pismeno);
			}
			
			hodnotaSlova += pismeno.getHodnota() * nasobicHodnotyPismena;
		}
		
		hodnotaSlova = nasobicHodnotySlova * hodnotaSlova;
		
		for (int x = zaciatokX; x <= koniecX; x++) {
			text += plocha[x][riadok].getPismeno().getZnak();
		}
		
		if (!slovnik.existujeSlovo(text)) {
			return null;
		}
		
		return new Slovo(zaciatokX, zaciatokY, koniecX, koniecY, text, hodnotaSlova, pouziteNovePismena);
	}
	
	/**
	 * Najde nove slovo, ktore lezi v stlpci na danych suradniciach
	 * @param stlpec v hernej ploche
	 * @param riadok v hernej ploche
	 * @return {@link Slovo} alebo <b>null</b>
	 */
	public Slovo najdiSlovoVStlpci(int stlpec, int riadok) {
		if (plocha[stlpec][riadok].getPismeno() == null || plocha[stlpec][riadok].getPismeno().isValidovane() == true) {
			return null;
		}
		
		int nasobicHodnotySlova = 1;
		int hodnotaSlova = 0;
		String text = "";
		int zaciatokX = stlpec;
		int zaciatokY = riadok;
		int koniecX = stlpec;
		int koniecY = riadok;
		ArrayList<Pismeno> pouziteNovePismena = new ArrayList<Pismeno>();
		
		for (int y = riadok; y >= 0; y--) {
			if (plocha[stlpec][y].getPismeno() == null) {
				break;
			}
			zaciatokY = y;
			
			int nasobicHodnotyPismena = 1;
			
			Pismeno pismeno = plocha[stlpec][y].getPismeno();
			
			if (pismeno.isValidovane() == false) {
				nasobicHodnotyPismena = Math.max(plocha[stlpec][y].hodnotaPismena(), nasobicHodnotyPismena);
				nasobicHodnotySlova = Math.max(plocha[stlpec][y].hodnotaSlova(), nasobicHodnotySlova);
				pouziteNovePismena.add(pismeno);
			}
			
			hodnotaSlova += pismeno.getHodnota() * nasobicHodnotyPismena;
		}
		for (int y = riadok+1; y < POCET_RIADKOV_PLOCHY; y++) {
			if (plocha[stlpec][y].getPismeno() == null) {
				break;
			}
			koniecY = y;
			
			int nasobicHodnotyPismena = 1;
			
			Pismeno pismeno = plocha[stlpec][y].getPismeno();
			
			if (pismeno.isValidovane() == false) {
				nasobicHodnotyPismena = Math.max(plocha[stlpec][y].hodnotaPismena(), nasobicHodnotyPismena);
				nasobicHodnotySlova = Math.max(plocha[stlpec][y].hodnotaSlova(), nasobicHodnotySlova);
				pouziteNovePismena.add(pismeno);
			}
			
			hodnotaSlova += pismeno.getHodnota() * nasobicHodnotyPismena;
		}
		
		hodnotaSlova = nasobicHodnotySlova * hodnotaSlova;
		
		for (int y = zaciatokY; y <= koniecY; y++) {
			text += plocha[stlpec][y].getPismeno().getZnak();
		}
		
		if (!slovnik.existujeSlovo(text)) {
			return null;
		}
		
		return new Slovo(zaciatokX, zaciatokY, koniecX, koniecY, text, hodnotaSlova, pouziteNovePismena);
	}
	
	/**
	 * Otestuje podmienku ukoncenia hry a vypise vytaza
	 */
	public void otestujAUkonciHru() {
		if (hraci == null || hraci.length == 0) {
			vytvorNovuHru();
			repaint();
			return;
		}
		
		boolean koniecHry = true;
		String vitazMeno = "";
		int vitazSkore = 0;
		
		for (int i = 0; i < hraci.length; i++) {
			koniecHry &= hraci[i].getNeuspesneKola() >= MAXIMALNY_POCET_NEUSPESNYCH_KOL;
			if (hraci[i].getSkore() > vitazSkore) {
				vitazSkore = hraci[i].getSkore();
				vitazMeno = hraci[i].getMeno();
			}
		}
		
		if (koniecHry) {
			if (vitazSkore > 0) {
				JOptionPane.showMessageDialog(this, "Hra skon�ila. Vyhral hr�� " + vitazMeno + " s " + Integer.toString(vitazSkore) + " bodmi.", "Scrabble", JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(this, "Hra skon�ila. Nevyhral nikto.", "Scrabble", JOptionPane.INFORMATION_MESSAGE);
			}
			hraci = null;
			repaint();
		}
	}
	
	/**
	 * Otestuje, ci su vsetky pismena na ploche ulozene spravne
	 * @return vrati <b>true</b>, ak je vsetko v poriadku
	 */
	private boolean otestujIntegrituHry() {
		int startStlpec = PolePlochy.ZACIATOCNA_PLOCHA_STLPEC;
		int startRiadok = PolePlochy.ZACIATOCNA_PLOCHA_RIADOK;
		
		if (plocha[startStlpec][startRiadok].getPismeno() != null) {
			LinkedList<Pair<Integer, Integer>> pismena = new LinkedList<Pair<Integer,Integer>>();
			pismena.addLast(new Pair<Integer, Integer>(startStlpec, startRiadok));
			HashSet<Pismeno> neoverenePismena = new HashSet<Pismeno>();
			
			synchronized (semaforSynchronizaciePlochy) {
				for (int stlpec = 0; stlpec < POCET_STLPCOV_PLOCHY; stlpec++) {
					for (int riadok = 0; riadok < POCET_RIADKOV_PLOCHY; riadok++) {
						if (plocha[stlpec][riadok].getPismeno() != null) {
							neoverenePismena.add(plocha[stlpec][riadok].getPismeno());
						}
					}
				}
			}
			
			while(pismena.size() > 0) {
				Pair<Integer, Integer> suradnice = pismena.pollFirst();
				int stlpec = suradnice.getValue1();
				int riadok = suradnice.getValue2();
				Pismeno pismeno = plocha[stlpec][riadok].getPismeno();
				if (pismeno != null && neoverenePismena.contains(pismeno)) {
					neoverenePismena.remove(pismeno);
					
					if (stlpec > 0) {
						pismena.addLast(new Pair<Integer, Integer>(stlpec - 1, riadok));
					}
					
					if (stlpec < POCET_STLPCOV_PLOCHY - 1) {
						pismena.addLast(new Pair<Integer, Integer>(stlpec + 1, riadok));
					}
					
					if (riadok > 0) {
						pismena.addLast(new Pair<Integer, Integer>(stlpec, riadok - 1));
					}
					
					if (riadok < POCET_RIADKOV_PLOCHY - 1) {
						pismena.addLast(new Pair<Integer, Integer>(stlpec, riadok + 1));
					}
				}
			}
			
			if (neoverenePismena.size() == 0) { 
				return true;
			}
		}
		
		return false;
	}
}

/**
 * Mikro semafor pre synchronizaciu
 * @author Andrej Jursa
 */
class MikroSemafor {}

/**
 * Vynimka pri vytvarani novej hry
 * @author Andrej Jursa
 */
class NewGameCancelException extends Exception {

	/**
	 * Vychodzie seriove cislo
	 */
	private static final long serialVersionUID = 1L;
	
}
