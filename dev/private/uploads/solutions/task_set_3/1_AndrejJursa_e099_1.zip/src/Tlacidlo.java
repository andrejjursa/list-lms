import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;


public class Tlacidlo implements MysouOvladatelne {

	/**
	 * Nazov / text na tlacidle
	 */
	private String nazov = "";
	
	/**
	 * Vyska tlacidla
	 */
	private int vyska = 0;
	
	/**
	 * Sirka tlacidla
	 */
	private int sirka = 0;
	
	/**
	 * Pozicia tlacidla x
	 */
	private int mojeX = 0;
	
	/**
	 * Pozicia tlacidla y
	 */
	private int mojeY = 0;
	
	/**
	 * Pismo tlacidla
	 */
	private Font pismo;
	
	/**
	 * Udalost, ktora je vyvolana po kliknuti na tlacidlo
	 */
	private UdalostTlacidla udalost;
	
	/**
	 * Ci je mys nad tymto tlacidlom
	 */
	private boolean mysNad = false;
	
	/**
	 * Referencia na applet hry
	 */
	private ScrabbleApplet applet;
	
	/**
	 * Konstruktor tlacidla
	 * @param nazov alebo text na tlacidle
	 * @param vyska tlacidla
	 * @param sirka tlacidla
	 * @param mojeX x-ova suradnica tlacidla
	 * @param mojeY y-ova suradnica tlacidla
	 * @param applet referencia na applet hry
	 */
	public Tlacidlo(String nazov, int vyska, int sirka, int mojeX, int mojeY, ScrabbleApplet applet) {
		super();
		this.nazov = nazov;
		this.vyska = vyska;
		this.sirka = sirka;
		this.mojeX = mojeX;
		this.mojeY = mojeY;
		this.applet = applet;
	}
	
	/**
	 * Nastavi utalost po kliknuti na tlacidlo
	 * @param udalost vyvolana kliknutim na tlacidlo
	 */
	public void setUdalost(UdalostTlacidla udalost) {
		this.udalost = udalost;
	}
	
	/**
	 * Vykreslenie tlacidla
	 * @param g graficka plocha
	 */
	public void paint(Graphics g) {
		Font pismoNazvu = zistiPismo(g);
		
		g.setColor(Color.white);
		g.fillRect(mojeX, mojeY, sirka, vyska);
		g.setColor(Color.gray);
		g.draw3DRect(mojeX, mojeY, sirka, vyska, !mysNad);
		
		g.setColor(Color.black);
		g.setFont(pismoNazvu);
		Rectangle2D rozmery = g.getFontMetrics().getStringBounds(nazov, g);
		g.drawString(nazov, mojeX + (int)(sirka - rozmery.getWidth()) / 2, mojeY + vyska - (int)(vyska - rozmery.getHeight()) / 2 - (int)(vyska * 0.1));
		
	}

	@Override
	public boolean jeMysNad(int mysX, int mysY, int dodatocneX, int dodatocneY) {
		boolean stareMysNad = mysNad;
		
		if (mysX >= mojeX && mysX <= mojeX + sirka && mysY >= mojeY && mysY <= mojeY + vyska) {
			mysNad = true;
		} else {
			mysNad = false;
		}
		
		if (mysNad != stareMysNad) {
			applet.repaint();
		}
		
		return mysNad;
	}

	@Override
	public void klikMysou(int mysX, int mysY, int dodatocneX, int dodatocneY) {
		if (jeMysNad(mysX, mysY, dodatocneX, dodatocneY)) {
			if (udalost != null) {
				udalost.vykonaj();
			}
		}
	}

	/**
	 * Vypocita pismo tak, aby sa text tlacidla zmestil do jeho tela
	 * @param g graficka plocha
	 * @return pismo
	 */
	private Font zistiPismo(Graphics g) {
		if (pismo == null) {
			int maximalnyFont = vyska - 4;
			int novyFont = maximalnyFont;
			Font novePismo = null;
			for (; novyFont > 0; novyFont--) {
				novePismo = new Font("Arial", Font.PLAIN, novyFont);
				g.setFont(novePismo);
				Rectangle2D rozmery = g.getFontMetrics().getStringBounds(nazov, g);
				if (rozmery.getWidth() <= sirka - 4 && rozmery.getHeight() <= vyska - 4) {
					break;
				}
			}
			
			pismo = novePismo;
		}
		
		return pismo;
	}
}
