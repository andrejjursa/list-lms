/**
 * Definuje graficke triedy, ktore sa daju oznacit mysou
 * @author Andrej Jursa
 */
public interface MysouOvladatelne {
	
	/**
	 * Zistuje, ci je mys nad objektom v grafickej ploche 
	 * @param mysX x-ova suradnica mysi
	 * @param mysY y-ova suradnica mysi
	 * @param dodatocneX x-ova dodatocna suradnica (nie suradnica mysi)
	 * @param dodatocneY y-ova dodatocna suradnica (nie suradnica mysi)
	 * @return vrati <b>true</b>, ak je oznacene mysou, inak <b>false</b>
	 */
	public boolean jeMysNad(int mysX, int mysY, int dodatocneX, int dodatocneY);
	
	public void klikMysou(int mysX, int mysY, int dodatocneX, int dodatocneY);
}
