import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 * Objekt hraca hry Scrabble
 * @author Andrej Jursa
 */
public class Hrac implements MysouOvladatelne {
	
	/**
	 * Vyska panela pismen
	 */
	public static final int VYSKA_PANELA_PISMEN = Pismeno.VYSKA + 10;
	
	/**
	 * Sirka panela pismen
	 */
	public static final int SIRKA_PANELA_PISMEN = ScrabbleApplet.POCET_STLPCOV_PLOCHY * PolePlochy.SIRKA + (ScrabbleApplet.POCET_STLPCOV_PLOCHY - 1) * PolePlochy.ROZSTUP_X;
	
	/**
	 * Lavy okraj pre kreslenie pismen
	 */
	public static final int PISMENA_LAVY_OKRAJ = 5;
	
	/**
	 * Rozstup pismen
	 */
	public static final int PISMANE_ROZOSTUP = 3;
	
	/**
	 * Meno hraca
	 */
	private String meno = "Hrac";
	
	/**
	 * Hracovo skore
	 */
	private int skore = 0;
	
	/**
	 * Farba hraca
	 */
	private Color farba = Color.black;
	
	/**
	 * Referencia na applet hry
	 */
	private ScrabbleApplet applet = null;
	
	/**
	 * Zasobnik hracovych pismen
	 */
	private ArrayList<Pismeno> zasobnikPismen = null;
	
	/**
	 * Pismeno vybrane na ulozenie
	 */
	private Pismeno pismenoNaUlozenie = null;
	
	/**
	 * Pocet neuspesnych kol (ked nebolo nic vlozene)
	 */
	private int neuspesneKola = 0;
	
	/**
	 * Konstruktor hraca
	 * @param meno hraca v hre
	 * @param farba hraca v hre
	 * @param applet referencia na applet
	 */
	public Hrac(String meno, Color farba, ScrabbleApplet applet) {
		this.meno = meno;
		this.applet = applet;
		this.farba = farba;
		
		zasobnikPismen = new ArrayList<Pismeno>();
		vlozMinimalnyPocetPismen();
	}
	
	/**
	 * Vrati meno hraca
	 * @return meno hraca
	 */
	public String getMeno() {
		return meno;
	}
	
	/**
	 * Vrati hracovo skore
	 * @return hracovo skore
	 */
	public int getSkore() {
		return skore;
	}
	
	/**
	 * Prida skore k sucasnemu skore hraca
	 * @param skore pridana hodnota k skore
	 */
	public void addScore(int skore) {
		if (skore < 0) { return; }
		this.skore += skore;
	}
	
	/**
	 * Vrati farbu hraca
	 * @return farba hraca
	 */
	public Color getFarba() {
		return farba;
	}
	
	/**
	 * Vrati pismeno, ktore je pripravene na ulozenie na hraciu plochu
	 * @return pismeno
	 */
	public Pismeno getPismenoNaUlozenie() {
		return pismenoNaUlozenie;
	}
	
	/**
	 * Vrati pocet neuspesnych kol
	 * @return neuspesne kola
	 */
	public int getNeuspesneKola() {
		return neuspesneKola;
	}
	
	/**
	 * Resetuje neuspesne kola na nulu
	 */
	public void resetujNeuspesneKola() {
		neuspesneKola = 0;
	}
	
	/**
	 * Zvisi neuspesne kola o jedno
	 */
	public void zvisNeuspesneKola() {
		neuspesneKola++;
	}

	/**
	 * Vrati pocet pismen v hracovom zasobniku pismen
	 * @return pocet pismen v zasobniku
	 */
	public int pocetPismenVZasobniku() {
		return zasobnikPismen.size();
	}
	
	/**
	 * Vlozi <i>n</i> nahodnych novych pismen do zasobniku daneho hraca
	 * <i>n</i> je od 1 - minimum (minimum je definovane v {@link ScrabbleApplet})
	 * @return vrati <b>true</b>, ak boli pismena vlozene, inak <b>false</b>
	 */
	public boolean vlozMinimalnyPocetPismen() {
		int potrebnyPocet = ScrabbleApplet.MIN_POCET_PISMEN_V_ZASOBNIKU - pocetPismenVZasobniku();
		if (potrebnyPocet > 0) {
			for (int i = 0; i < potrebnyPocet; i++) {
				pridajJednoPismeno();
			}
			return true;
		}
		return false;
	}
	
	/**
	 * Vlozi najviac 2 pismena do zasobniku pismen
	 * @return vrati <b>true</b>, ak bolo mozne pismena vlozit, inak <b>false</b>
	 */
	public boolean vlozNajviac2Pismena() {
		if (pocetPismenVZasobniku() < ScrabbleApplet.MAX_POCET_PISMEN_V_ZASOBNIKU) {
			int pocet = ScrabbleApplet.MAX_POCET_PISMEN_V_ZASOBNIKU - pocetPismenVZasobniku();
			pocet = pocet > 2 ? 2 : pocet;
			for (int i = 0; i < pocet; i++) {
				pridajJednoPismeno();
			}
			return true;
		}
		return false;
	}
	
	/**
	 * Vlozi do zasobniku pismena
	 * @return vrati <b>true</b>, ak boli nejake pismena vlozene
	 */
	public boolean pridajPismenaDoZasobniku() {
		if (pocetPismenVZasobniku() >= ScrabbleApplet.MIN_POCET_PISMEN_V_ZASOBNIKU - 1) {
			return vlozNajviac2Pismena();
		}
		return vlozMinimalnyPocetPismen();
	}
	
	/**
	 * Vyhodi vsetky pismena zo zasobnika pismen a vlozi do nich nove
	 * @return vrati <b>true</b>, ak sa operacia podarila
	 */
	public boolean vymenPismenaVZasobniku() {
		zasobnikPismen = new ArrayList<Pismeno>();
		return vlozMinimalnyPocetPismen();
	}
	
	/**
	 * Vytvori jedno pismeno v zasobniku
	 */
	private void pridajJednoPismeno() {
		char znak = applet.getSlovnik().nahodnyZnak();
		int hodnota = applet.getSlovnik().hodnotaZnaku(znak);
		zasobnikPismen.add(new Pismeno(znak, hodnota, applet));
	}
	
	/**
	 * Vykreslenie panela pismen
	 * @param g graficka plocha
	 */
	public void paint(Graphics g) {
		int mojeX = ScrabbleApplet.ODSADENIE_PANELA_PISMEN_ZLAVA;
		int mojeY = ScrabbleApplet.ODSADENIE_PANELA_PISMEN_ZHORA;
		
		g.setColor(Color.green);
		g.fillRect(mojeX, mojeY, SIRKA_PANELA_PISMEN, VYSKA_PANELA_PISMEN);
		g.setColor(Color.black);
		g.drawRect(mojeX, mojeY, SIRKA_PANELA_PISMEN, VYSKA_PANELA_PISMEN);
		
		int pismeno_x = startPoziciaPismenX();
		int pismeno_y = startPoziciaPismenY();
		
		for (Pismeno pismeno: zasobnikPismen) {
			pismeno.paint(g, pismeno_x, pismeno_y, pismenoNaUlozenie);
			pismeno_x += Pismeno.SIRKA + PISMANE_ROZOSTUP;
		}
	}
	
	/**
	 * X-ova pozicia prveho pismena v zozname
	 * @return x-ova pozicia
	 */
	private int startPoziciaPismenX() {
		int mojeX = ScrabbleApplet.ODSADENIE_PANELA_PISMEN_ZLAVA;
		return mojeX + PISMENA_LAVY_OKRAJ;
	}
	
	/**
	 * Y-ova pozicia prveho pismena v zovname
	 * @return y-ova pozicia
	 */
	private int startPoziciaPismenY() {
		int mojeY = ScrabbleApplet.ODSADENIE_PANELA_PISMEN_ZHORA;
		return (int)((VYSKA_PANELA_PISMEN - Pismeno.VYSKA) / 2) + mojeY;
	}
	
	/**
	 * Nastavy pismeno vybrane na ulozenie do hracej plochy
	 * @param pismeno ktore chceme ulozit do plochy
	 */
	public void vyberPismenoNaUlozenie(Pismeno pismeno) {
		if (zasobnikPismen.contains(pismeno)) {
			pismenoNaUlozenie = pismeno;
		} else {
			zrusVyberPismena();
		}
	}
	
	/**
	 * Zrusi vyber pismena
	 */
	public void zrusVyberPismena() {
		pismenoNaUlozenie = null;
	}
	
	/**
	 * Odoberie zo zasobnika pismeno
	 */
	public void odoberVybranePismenoZoZasobnika() {
		if (pismenoNaUlozenie != null) {
			pismenoNaUlozenie.setValidovane(false);
			pismenoNaUlozenie.setVyberatelne(false);
			zasobnikPismen.remove(pismenoNaUlozenie);
			zrusVyberPismena();
		}
	}
	
	/**
	 * Vlozi do zasobnika zadane pismeno
	 * @param pismeno ktore sa ma vlozit do zasobnika
	 */
	public boolean vlozPismenoDoZasobnika(Pismeno pismeno) {
		if (pismeno != null) {
			if (pocetPismenVZasobniku() >= ScrabbleApplet.MAX_POCET_PISMEN_V_ZASOBNIKU) {
				return false;
			}
			zasobnikPismen.add(pismeno);
			pismeno.setValidovane(true);
			pismeno.setVyberatelne(true);
			return true;
		}
		return false;
	}

	@Override
	public boolean jeMysNad(int mysX, int mysY, int dodatocneX, int dodatocneY) {
		int pismeno_x = startPoziciaPismenX();
		int pismeno_y = startPoziciaPismenY();
		
		for (Pismeno pismeno: zasobnikPismen) {
			pismeno.jeMysNad(mysX, mysY, pismeno_x, pismeno_y);
			pismeno_x += Pismeno.SIRKA + PISMANE_ROZOSTUP;
		}
		return false;
	}

	@Override
	public void klikMysou(int mysX, int mysY, int dodatocneX, int dodatocneY) {
		int pismeno_x = startPoziciaPismenX();
		int pismeno_y = startPoziciaPismenY();
		
		for (Pismeno pismeno: zasobnikPismen) {
			pismeno.klikMysou(mysX, mysY, pismeno_x, pismeno_y);
			pismeno_x += Pismeno.SIRKA + PISMANE_ROZOSTUP;
		}
	}
	
}
