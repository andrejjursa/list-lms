import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

/**
 * Pismeno pre hru Scrabble
 * @author Andrej Jursa
 */
public class Pismeno implements MysouOvladatelne {
	
	/**
	 * Sirka znacky pismena
	 */
	public static final int SIRKA = 36;
	
	/**
	 * Vyska znacky pismena
	 */
	public static final int VYSKA = 36;
	
	/**
	 * Zaoblenie rohov znacky pismena
	 */
	public static final int ZAOBLENIE_ROHOV = 5;
	
	/**
	 * Korekcia umiestnenia pismena vertikalne
	 */
	private static final int KOREKCIA_VYSKY_ZNAKU = 3;
	
	/**
	 * Korekcia umiestnenia pismena horizontalne
	 */
	private static final int KOREKCIA_SIRKY_ZNAKU = 1;
	
	/**
	 * Hodnota, ktoru treba overovat pri kontrole oznacenia pismena pomocou grafickej masky
	 */
	private static final int OZNACENIE_PISMENA = -1;
	
	/**
	 * Referencia na applet hry
	 */
	private ScrabbleApplet applet = null;
	
	/**
	 * Aky znak predstavuje tento objekt pismena
	 */
	private char znak = ' ';
	
	/**
	 * Reprezentuje hodnotu tohoto pismena v hre
	 */
	private int hodnota = 0;
	
	/**
	 * Validovanie slova obsahujuce toto pismeno, ak je nastavene na <b>true</b>, toto slovo uz bolo validovane
	 */
	private boolean validovane = true;
	
	/**
	 * Ci je toto pismeno oznacitelne (napr. pre umiestnovanie na plochu hry).
	 */
	private boolean vyberatelne = true;
	
	/**
	 * Ci je mys nad tymto pismenom
	 */
	private boolean mysNad = false;
	
	/**
	 * Graficka maska pismena, kvoli selekcii mysou
	 */
	private static BufferedImage maska = null;
	
	/**
	 * Konstruktor pismena
	 * @param znak ktory bude toto pismeno predstavovat
	 * @param hodnota tohoto znaku v hre 
	 * @param applet referencia na applet hry
	 */
	public Pismeno(char znak, int hodnota, ScrabbleApplet applet) {
		this.znak = znak;
		this.hodnota = hodnota;
		this.applet = applet;
	}
	
	/**
	 * Vrati informaciu, ci je toto pismeno uz zvalidovane
	 * @return <b>true</b>, ak je zvalidovane
	 */
	public boolean isValidovane() {
		return validovane;
	}
	
	/**
	 * Nastavi informaciu, ci je toto pismeno uz zvalidovane
	 * @param validovane <b>true</b> pre zvalidovane, inak <b>false</b>
	 */
	public void setValidovane(boolean validovane) {
		this.validovane = validovane;
	}

	/**
	 * Vrati informaciu, ci je toto pismeno vyberatelne mysou
	 * @return <b>true</b>, ak je vyberatelne mysou
	 */
	public boolean isVyberatelne() {
		return vyberatelne;
	}

	/**
	 * Nastavi vyberatelnost tohoto pismena mysou
	 * @param vyberatelne prepinac vyberania
	 */
	public void setVyberatelne(boolean vyberatelne) {
		this.vyberatelne = vyberatelne;
	}

	/**
	 * Vykreslenie pismena na graficku plochu
	 * @param g 
	 * @param startX
	 * @param startY
	 * @param naulozenie referencia na pismeno u hraca vybrana na ulozenie do hernej plochy
	 */
	public void paint(Graphics g, int startX, int startY, Pismeno naulozenie) {
		Color pozadiePismena = new Color(241, 242, 235);
		g.setColor(pozadiePismena);
		if (naulozenie == this) {
			g.setColor(new Color(255, 105, 105));
		}
		if (mysNad && vyberatelne) {
			g.setColor(new Color(186, 192, 185));
		}
		g.fillRoundRect(startX, startY, SIRKA, VYSKA, ZAOBLENIE_ROHOV, ZAOBLENIE_ROHOV);
		g.setColor(Color.black);
		if (!validovane) {
			g.setColor(Color.red);
		}
		g.drawRoundRect(startX, startY, SIRKA, VYSKA, ZAOBLENIE_ROHOV, ZAOBLENIE_ROHOV);
		g.setColor(Color.black);
		g.setFont(new Font("Arial", Font.BOLD, 2 * (VYSKA / 3)));
		Rectangle2D rozmer = g.getFontMetrics().getStringBounds(znak + "", g);
		g.drawString(znak + "", (int)(startX + (SIRKA - rozmer.getWidth()) / 2 + KOREKCIA_SIRKY_ZNAKU), (int)(startY + VYSKA / 2 + rozmer.getHeight() / 2 - KOREKCIA_VYSKY_ZNAKU));
		g.setFont(new Font("Arial", Font.PLAIN, (int)(VYSKA * 0.25)));
		rozmer = g.getFontMetrics().getStringBounds(Integer.toString(hodnota), g);
		g.drawString(Integer.toString(hodnota), (int)(startX + SIRKA - rozmer.getWidth() - ZAOBLENIE_ROHOV * 0.2), (int)(startY + VYSKA - ZAOBLENIE_ROHOV * 0.2));
	}

	@Override
	public boolean jeMysNad(int mysX, int mysY, int dodatocneX, int dodatocneY) {
		boolean stareMysNad = mysNad;
		
		if (!vyberatelne) {
			mysNad = false;
			
			if (stareMysNad != mysNad) {
				applet.repaint();
			}
			
			return mysNad;
		}
		
		BufferedImage maska = vratMasku();
		int realneX = mysX - dodatocneX;
		int realneY = mysY - dodatocneY;
		
		if (realneX >= 0 && realneX <= SIRKA && realneY >= 0 && realneY <= VYSKA) {
			try {
				//System.out.println("Na " + realneX + " x " + realneY + " = " + maska.getRGB(realneX, realneY));
				if (maska.getRGB(realneX, realneY) == OZNACENIE_PISMENA) {
					mysNad = true;
				} else {
					mysNad = false;
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				mysNad = false;
				System.err.println(realneX + " x " + realneY);
				e.printStackTrace();
			}
		} else {
			mysNad = false;
		}
		
		if (stareMysNad != mysNad) {
			applet.repaint();
		}
		
		return mysNad;
	}

	@Override
	public void klikMysou(int mysX, int mysY, int dodatocneX, int dodatocneY) {
		if (jeMysNad(mysX, mysY, dodatocneX, dodatocneY) && vyberatelne) {
			Pismeno vybrane = applet.hracNaTahu().getPismenoNaUlozenie();
			if (vybrane == this) {
				applet.hracNaTahu().zrusVyberPismena();
			} else {
				applet.hracNaTahu().vyberPismenoNaUlozenie(this);
			}
			applet.repaint();
		}
	}
	
	/**
	 * Vrati masku, vygeneruje ju ak nebola este vygenerovana
	 * @return maska
	 */
	private BufferedImage vratMasku() {
		if (maska == null) {
			maska = new BufferedImage(SIRKA + 1, VYSKA + 1, BufferedImage.TYPE_INT_ARGB);
			
			Graphics g = maska.getGraphics();
			g.setColor(Color.black);
			g.fillRect(0, 0, SIRKA + 1, VYSKA + 1);
			g.drawRect(0, 0, SIRKA + 1, VYSKA + 1);
			g.setColor(Color.white);
			g.fillRoundRect(0, 0, SIRKA, VYSKA, ZAOBLENIE_ROHOV, ZAOBLENIE_ROHOV);
			g.drawRoundRect(0, 0, SIRKA, VYSKA, ZAOBLENIE_ROHOV, ZAOBLENIE_ROHOV);
		}
		return maska;
	}

	/**
	 * Vrati znak pismena
	 * @return znak pismena
	 */
	public char getZnak() {
		return znak;
	}

	/**
	 * Vrati hodnotu pismena
	 * @return hodnota pismena
	 */
	public int getHodnota() {
		return hodnota;
	}
	
}
