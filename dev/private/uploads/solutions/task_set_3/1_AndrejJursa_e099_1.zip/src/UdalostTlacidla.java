/**
 * Interface pre udalost po kliknuti na tlacidlo
 * @author Andrej Jursa
 */
public interface UdalostTlacidla {
	
	/**
	 * Metoda, ktora sa zavola po stlaceni tlacidla
	 */
	public void vykonaj();
	
}
