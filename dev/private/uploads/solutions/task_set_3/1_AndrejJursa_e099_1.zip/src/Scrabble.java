import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JApplet;
import javax.swing.JFrame;

/**
 * Hlavna aplikacia pre hru Scrabble
 * 
 * @author Andrej Jursa
 */
public class Scrabble {

	/**
	 * Hlavna procedura aplikacie
	 * @param args vstupne argumenty
	 */
	public static void main(String[] args) {
		ScrabbleApplet scrabbleApplet = new ScrabbleApplet();
		scrabbleApplet.setCestaKSlovniku("./lexicon/slovnik.txt");
		scrabbleApplet.init();
		scrabbleApplet.start();
		
		MakeFrame(scrabbleApplet, 850, 850, "Scrabble");
	}
	
	/**
	 * Vytvori frame z JApplet-u
	 * @param jp JApplet umiestneny do framu
	 * @param width sirka framu
	 * @param height vyska framu
	 * @param frameName nazov framu
	 */
	public static void MakeFrame(JApplet jp, int width, int height, String frameName) {
		JFrame frame = new JFrame(frameName/*jp.getClass().toString()*/); // pomenuj frame
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
		frame.getContentPane().add(jp, BorderLayout.CENTER);  // vloz JPanel do frame
		frame.setSize(width, height);
		frame.setVisible(true);	// zobraz frame na obrazovke
	}

}
